library('mlbench')
Ionosphere$V1<-NULL
Ionosphere$V2<-NULL
Ionosphere$Class<-NULL

y<-Ionosphere[,32]
x<- as.matrix(Ionosphere[,-32])

library(MASS)
fit <- lm(V34~., data = Ionosphere)
step <- stepAIC(fit, direction="both")
step
AIC(lm( V34 ~ V4 + V5 + V7 + V8 + V9 + V11 + V12 + V13 + 
          V14 + V15 + V16 + V18 + V19 + V20 + V23 + V25 + V27 + V29 + 
          V30 + V31 + V32 + V33, data = Ionosphere))

par(mfrow=c(3,1))
test_that('Variable selection using genetic algorithms',{
  test1 <-GA:: select(y, x, 
                  crossover_method = 'method1', nCores = 1L)
  
  expect_equal(test1$optimize$value, AIC(lm( V34 ~ V4 + V5 + V7 + V8 + V9 + V11 + V12 + V13 + 
                                               V14 + V15 + V16 + V18 + V19 + V20 + V23 + V25 + V27 + V29 + 
                                               V30 + V31 + V32 + V33, data = Ionosphere)),
               tolerance = 2e0)
})
test1 <-GA:: select(y, x, crossover_method = 'method1', nCores = 1L)
test1$optimize$value
plot(test1, col1 = "blue", col2 = "red")


test_that('Variable selection using genetic algorithms',{
  test2 <-GA:: select(y, x, 
                      crossover_method = 'method2', nCores = 1L)
  
  expect_equal(test2$optimize$value, AIC(lm( V34 ~ V4 + V5 + V7 + V8 + V9 + V11 + V12 + V13 + 
                                               V14 + V15 + V16 + V18 + V19 + V20 + V23 + V25 + V27 + V29 + 
                                               V30 + V31 + V32 + V33, data = Ionosphere)),
               tolerance = 2e0)
})
test2 <-GA:: select(y, x, crossover_method = 'method2', nCores = 1L)
test2$optimize$value
plot(test2, col1 = "blue", col2 = "red")


test_that('Variable selection using genetic algorithms',{
  test1 <-GA:: select(y, x, 
                      crossover_method = 'method3', nCores = 1L)
  
  expect_equal(test1$optimize$value, AIC(lm( V34 ~ V4 + V5 + V7 + V8 + V9 + V11 + V12 + V13 + 
                                               V14 + V15 + V16 + V18 + V19 + V20 + V23 + V25 + V27 + V29 + 
                                               V30 + V31 + V32 + V33, data = Ionosphere)),
               tolerance = 2e0)
})

test3 <-GA:: select(y, x, crossover_method = 'method3', nCores = 1L)
test3$optimize$value
plot(test1, col1 = "blue", col2 = "red")